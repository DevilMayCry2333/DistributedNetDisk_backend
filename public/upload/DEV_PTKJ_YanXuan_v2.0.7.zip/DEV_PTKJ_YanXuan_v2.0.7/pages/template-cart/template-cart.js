var app = getApp()
Page({
  data: {},
  onLoad:function(){
    wx.showLoading({
      title: '加载中...',
      mask:true
    })
  }
})
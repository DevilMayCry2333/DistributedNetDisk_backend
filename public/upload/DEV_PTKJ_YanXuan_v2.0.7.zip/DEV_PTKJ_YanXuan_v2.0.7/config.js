var config = {
  'url': 'https://api.it120.cc/',//链接源，不需要修改
  'subDomain': 'formatTime',//这里填写你自己的域名，比如你的域名是 https://it120.cc/abcd 你只需要填写 abcd 就好了
  'version': '2.0.8',//版本号
  'shareProfile': '清欢严选商城2.0.8',//转发话术，你可以自定义这段话
  'closeorderkey': 'mGVFc31MYNMoR9Z-A9yeVVYLIVGphUVcK2-S2UdZHmg',//关闭订单模版ID，这里填写你自己的模版消息ID
  'deliveryorderkey': 'Arm2aS1rsklRuJSrfz-QVoyUzLVmU2vEMn_HgMxuegw',//发货提醒模版ID，这里填写你自己的模版消息ID
  'assessorderkey': 'ZH2jCVMa88OMxki3C65hLL1WB0Cq4ZoOWAzMVd0kwUU',//评价模版提醒ID，这里填写你自己的模版消息ID
  'successorderkey': 'lKBY11dSkxiii6GB833V-hFfHjbBYs0vFt_otqMKG_4'//已评价模版提醒ID，这里填写你自己的模版消息ID
}
module.exports = config         
